<?php

namespace Design\InitializrBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Admin
 *
 * @ORM\Table(name="admin")
 * @ORM\Entity
 */
class Admin
{
    /**
     * @var string
     *
     * @ORM\Column(name="mdp_admin", type="string", length=128, nullable=false)
     */
    private $mdpAdmin;

    /**
     * @var string
     *
     * @ORM\Column(name="salt_admin", type="string", length=128, nullable=false)
     */
    private $saltAdmin;

    /**
     * @var boolean
     *
     * @ORM\Column(name="active_admin", type="boolean", nullable=false)
     */
    private $activeAdmin;

    /**
     * @var \Design\InitializrBundle\Entity\Personne
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Design\InitializrBundle\Entity\Personne")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="id_admin", referencedColumnName="id_personne")
     * })
     */
    private $idAdmin;



    /**
     * Set mdpAdmin
     *
     * @param string $mdpAdmin
     * @return Admin
     */
    public function setMdpAdmin($mdpAdmin)
    {
        $this->mdpAdmin = $mdpAdmin;

        return $this;
    }

    /**
     * Get mdpAdmin
     *
     * @return string 
     */
    public function getMdpAdmin()
    {
        return $this->mdpAdmin;
    }

    /**
     * Set saltAdmin
     *
     * @param string $saltAdmin
     * @return Admin
     */
    public function setSaltAdmin($saltAdmin)
    {
        $this->saltAdmin = $saltAdmin;

        return $this;
    }

    /**
     * Get saltAdmin
     *
     * @return string 
     */
    public function getSaltAdmin()
    {
        return $this->saltAdmin;
    }

    /**
     * Set activeAdmin
     *
     * @param boolean $activeAdmin
     * @return Admin
     */
    public function setActiveAdmin($activeAdmin)
    {
        $this->activeAdmin = $activeAdmin;

        return $this;
    }

    /**
     * Get activeAdmin
     *
     * @return boolean 
     */
    public function getActiveAdmin()
    {
        return $this->activeAdmin;
    }

    /**
     * Set idAdmin
     *
     * @param \Design\InitializrBundle\Entity\Personne $idAdmin
     * @return Admin
     */
    public function setIdAdmin(\Design\InitializrBundle\Entity\Personne $idAdmin)
    {
        $this->idAdmin = $idAdmin;

        return $this;
    }

    /**
     * Get idAdmin
     *
     * @return \Design\InitializrBundle\Entity\Personne 
     */
    public function getIdAdmin()
    {
        return $this->idAdmin;
    }
}
