<?php

namespace Design\InitializrBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Cours
 *
 * @ORM\Table(name="cours", indexes={@ORM\Index(name="FK_Cours_instrument", columns={"instrument"})})
 * @ORM\Entity
 */
class Cours
{
    /**
     * @var integer
     *
     * @ORM\Column(name="periodicite", type="integer", nullable=false)
     */
    private $periodicite;

    /**
     * @var \Design\InitializrBundle\Entity\Stage
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Design\InitializrBundle\Entity\Stage")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="id_cours", referencedColumnName="id_stage")
     * })
     */
    private $idCours;

    /**
     * @var \Design\InitializrBundle\Entity\Instrument
     *
     * @ORM\ManyToOne(targetEntity="Design\InitializrBundle\Entity\Instrument")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="instrument", referencedColumnName="id_instrument")
     * })
     */
    private $instrument;



    /**
     * Set periodicite
     *
     * @param integer $periodicite
     * @return Cours
     */
    public function setPeriodicite($periodicite)
    {
        $this->periodicite = $periodicite;

        return $this;
    }

    /**
     * Get periodicite
     *
     * @return integer 
     */
    public function getPeriodicite()
    {
        return $this->periodicite;
    }

    /**
     * Set idCours
     *
     * @param \Design\InitializrBundle\Entity\Stage $idCours
     * @return Cours
     */
    public function setIdCours(\Design\InitializrBundle\Entity\Stage $idCours)
    {
        $this->idCours = $idCours;

        return $this;
    }

    /**
     * Get idCours
     *
     * @return \Design\InitializrBundle\Entity\Stage 
     */
    public function getIdCours()
    {
        return $this->idCours;
    }

    /**
     * Set instrument
     *
     * @param \Design\InitializrBundle\Entity\Instrument $instrument
     * @return Cours
     */
    public function setInstrument(\Design\InitializrBundle\Entity\Instrument $instrument = null)
    {
        $this->instrument = $instrument;

        return $this;
    }

    /**
     * Get instrument
     *
     * @return \Design\InitializrBundle\Entity\Instrument 
     */
    public function getInstrument()
    {
        return $this->instrument;
    }
}
