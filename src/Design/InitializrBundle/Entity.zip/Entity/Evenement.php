<?php

namespace Design\InitializrBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Evenement
 *
 * @ORM\Table(name="evenement", indexes={@ORM\Index(name="FK_Evenement_personne_evenement", columns={"personne_evenement"})})
 * @ORM\Entity
 */
class Evenement
{
    /**
     * @var string
     *
     * @ORM\Column(name="nom_evenement", type="string", length=25, nullable=false)
     */
    private $nomEvenement;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_evenement", type="date", nullable=false)
     */
    private $dateEvenement;

    /**
     * @var integer
     *
     * @ORM\Column(name="duree_evenement", type="integer", nullable=false)
     */
    private $dureeEvenement;

    /**
     * @var string
     *
     * @ORM\Column(name="description_evenement", type="text", nullable=false)
     */
    private $descriptionEvenement;

    /**
     * @var boolean
     *
     * @ORM\Column(name="est_valide_evenement", type="boolean", nullable=false)
     */
    private $estValideEvenement;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_evenement", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idEvenement;

    /**
     * @var \Design\InitializrBundle\Entity\Personne
     *
     * @ORM\ManyToOne(targetEntity="Design\InitializrBundle\Entity\Personne")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="personne_evenement", referencedColumnName="id_personne")
     * })
     */
    private $personneEvenement;



    /**
     * Set nomEvenement
     *
     * @param string $nomEvenement
     * @return Evenement
     */
    public function setNomEvenement($nomEvenement)
    {
        $this->nomEvenement = $nomEvenement;

        return $this;
    }

    /**
     * Get nomEvenement
     *
     * @return string 
     */
    public function getNomEvenement()
    {
        return $this->nomEvenement;
    }

    /**
     * Set dateEvenement
     *
     * @param \DateTime $dateEvenement
     * @return Evenement
     */
    public function setDateEvenement($dateEvenement)
    {
        $this->dateEvenement = $dateEvenement;

        return $this;
    }

    /**
     * Get dateEvenement
     *
     * @return \DateTime 
     */
    public function getDateEvenement()
    {
        return $this->dateEvenement;
    }

    /**
     * Set dureeEvenement
     *
     * @param integer $dureeEvenement
     * @return Evenement
     */
    public function setDureeEvenement($dureeEvenement)
    {
        $this->dureeEvenement = $dureeEvenement;

        return $this;
    }

    /**
     * Get dureeEvenement
     *
     * @return integer 
     */
    public function getDureeEvenement()
    {
        return $this->dureeEvenement;
    }

    /**
     * Set descriptionEvenement
     *
     * @param string $descriptionEvenement
     * @return Evenement
     */
    public function setDescriptionEvenement($descriptionEvenement)
    {
        $this->descriptionEvenement = $descriptionEvenement;

        return $this;
    }

    /**
     * Get descriptionEvenement
     *
     * @return string 
     */
    public function getDescriptionEvenement()
    {
        return $this->descriptionEvenement;
    }

    /**
     * Set estValideEvenement
     *
     * @param boolean $estValideEvenement
     * @return Evenement
     */
    public function setEstValideEvenement($estValideEvenement)
    {
        $this->estValideEvenement = $estValideEvenement;

        return $this;
    }

    /**
     * Get estValideEvenement
     *
     * @return boolean 
     */
    public function getEstValideEvenement()
    {
        return $this->estValideEvenement;
    }

    /**
     * Get idEvenement
     *
     * @return integer 
     */
    public function getIdEvenement()
    {
        return $this->idEvenement;
    }

    /**
     * Set personneEvenement
     *
     * @param \Design\InitializrBundle\Entity\Personne $personneEvenement
     * @return Evenement
     */
    public function setPersonneEvenement(\Design\InitializrBundle\Entity\Personne $personneEvenement = null)
    {
        $this->personneEvenement = $personneEvenement;

        return $this;
    }

    /**
     * Get personneEvenement
     *
     * @return \Design\InitializrBundle\Entity\Personne 
     */
    public function getPersonneEvenement()
    {
        return $this->personneEvenement;
    }
}
