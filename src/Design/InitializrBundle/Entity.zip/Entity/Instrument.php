<?php

namespace Design\InitializrBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Instrument
 *
 * @ORM\Table(name="instrument")
 * @ORM\Entity
 */
class Instrument
{
    /**
     * @var string
     *
     * @ORM\Column(name="nom_instrument", type="string", length=25, nullable=false)
     */
    private $nomInstrument;

    /**
     * @var string
     *
     * @ORM\Column(name="description_instrument", type="text", nullable=true)
     */
    private $descriptionInstrument;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_instrument", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idInstrument;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Design\InitializrBundle\Entity\Personne", mappedBy="instrumentPratique")
     */
    private $personnePratique;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Design\InitializrBundle\Entity\Stage", mappedBy="instrumentPortesur")
     */
    private $stagePortesur;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->personnePratique = new \Doctrine\Common\Collections\ArrayCollection();
        $this->stagePortesur = new \Doctrine\Common\Collections\ArrayCollection();
    }


    /**
     * Set nomInstrument
     *
     * @param string $nomInstrument
     * @return Instrument
     */
    public function setNomInstrument($nomInstrument)
    {
        $this->nomInstrument = $nomInstrument;

        return $this;
    }

    /**
     * Get nomInstrument
     *
     * @return string 
     */
    public function getNomInstrument()
    {
        return $this->nomInstrument;
    }

    /**
     * Set descriptionInstrument
     *
     * @param string $descriptionInstrument
     * @return Instrument
     */
    public function setDescriptionInstrument($descriptionInstrument)
    {
        $this->descriptionInstrument = $descriptionInstrument;

        return $this;
    }

    /**
     * Get descriptionInstrument
     *
     * @return string 
     */
    public function getDescriptionInstrument()
    {
        return $this->descriptionInstrument;
    }

    /**
     * Get idInstrument
     *
     * @return integer 
     */
    public function getIdInstrument()
    {
        return $this->idInstrument;
    }

    /**
     * Add personnePratique
     *
     * @param \Design\InitializrBundle\Entity\Personne $personnePratique
     * @return Instrument
     */
    public function addPersonnePratique(\Design\InitializrBundle\Entity\Personne $personnePratique)
    {
        $this->personnePratique[] = $personnePratique;

        return $this;
    }

    /**
     * Remove personnePratique
     *
     * @param \Design\InitializrBundle\Entity\Personne $personnePratique
     */
    public function removePersonnePratique(\Design\InitializrBundle\Entity\Personne $personnePratique)
    {
        $this->personnePratique->removeElement($personnePratique);
    }

    /**
     * Get personnePratique
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPersonnePratique()
    {
        return $this->personnePratique;
    }

    /**
     * Add stagePortesur
     *
     * @param \Design\InitializrBundle\Entity\Stage $stagePortesur
     * @return Instrument
     */
    public function addStagePortesur(\Design\InitializrBundle\Entity\Stage $stagePortesur)
    {
        $this->stagePortesur[] = $stagePortesur;

        return $this;
    }

    /**
     * Remove stagePortesur
     *
     * @param \Design\InitializrBundle\Entity\Stage $stagePortesur
     */
    public function removeStagePortesur(\Design\InitializrBundle\Entity\Stage $stagePortesur)
    {
        $this->stagePortesur->removeElement($stagePortesur);
    }

    /**
     * Get stagePortesur
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getStagePortesur()
    {
        return $this->stagePortesur;
    }
}
