<?php

namespace Design\InitializrBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Membre
 *
 * @ORM\Table(name="membre")
 * @ORM\Entity
 */
class Membre
{
	public function __construct()
	{
		$this->estValideMembre = false; // active plus tard par l'admin
		$this->activeMembre = false;	// active lors de la connection
	}
	
    /**
     * @var string
     *
     * @ORM\Column(name="mdp_membre", type="string", length=128, nullable=false)
     */
    private $mdpMembre;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_naissance", type="date", nullable=false)
     */
    private $dateNaissance;

    /**
     * @var string
     *
     * @ORM\Column(name="adresse", type="text", nullable=false)
     */
    private $adresse;

    /**
     * @var boolean
     *
     * @ORM\Column(name="est_valide_membre", type="boolean", nullable=false)
     */
    private $estValideMembre;

    /**
     * @var string
     *
     * @ORM\Column(name="salt_membre", type="string", length=128, nullable=false)
     */
    private $saltMembre;

    /**
     * @var boolean
     *
     * @ORM\Column(name="active_membre", type="boolean", nullable=false)
     */
    private $activeMembre;

    /**
     * @var \Design\InitializrBundle\Entity\Personne
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Design\InitializrBundle\Entity\Personne")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="id_membre", referencedColumnName="id_personne")
     * })
     */
    private $idMembre;



    /**
     * Set mdpMembre
     *
     * @param string $mdpMembre
     * @return Membre
     */
    public function setMdpMembre($mdpMembre)
    {
        $this->mdpMembre = $mdpMembre;

        return $this;
    }

    /**
     * Get mdpMembre
     *
     * @return string 
     */
    public function getMdpMembre()
    {
        return $this->mdpMembre;
    }

    /**
     * Set dateNaissance
     *
     * @param \DateTime $dateNaissance
     * @return Membre
     */
    public function setDateNaissance($dateNaissance)
    {
        $this->dateNaissance = $dateNaissance;

        return $this;
    }

    /**
     * Get dateNaissance
     *
     * @return \DateTime 
     */
    public function getDateNaissance()
    {
        return $this->dateNaissance;
    }

    /**
     * Set adresse
     *
     * @param string $adresse
     * @return Membre
     */
    public function setAdresse($adresse)
    {
        $this->adresse = $adresse;

        return $this;
    }

    /**
     * Get adresse
     *
     * @return string 
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * Set estValideMembre
     *
     * @param boolean $estValideMembre
     * @return Membre
     */
    public function setEstValideMembre($estValideMembre)
    {
        $this->estValideMembre = $estValideMembre;

        return $this;
    }

    /**
     * Get estValideMembre
     *
     * @return boolean 
     */
    public function getEstValideMembre()
    {
        return $this->estValideMembre;
    }

    /**
     * Set saltMembre
     *
     * @param string $saltMembre
     * @return Membre
     */
    public function setSaltMembre($saltMembre)
    {
        $this->saltMembre = $saltMembre;

        return $this;
    }

    /**
     * Get saltMembre
     *
     * @return string 
     */
    public function getSaltMembre()
    {
        return $this->saltMembre;
    }

    /**
     * Set activeMembre
     *
     * @param boolean $activeMembre
     * @return Membre
     */
    public function setActiveMembre($activeMembre)
    {
        $this->activeMembre = $activeMembre;

        return $this;
    }

    /**
     * Get activeMembre
     *
     * @return boolean 
     */
    public function getActiveMembre()
    {
        return $this->activeMembre;
    }

    /**
     * Set idMembre
     *
     * @param \Design\InitializrBundle\Entity\Personne $idMembre
     * @return Membre
     */
    public function setIdMembre(\Design\InitializrBundle\Entity\Personne $idMembre)
    {
        $this->idMembre = $idMembre;

        return $this;
    }

    /**
     * Get idMembre
     *
     * @return \Design\InitializrBundle\Entity\Personne 
     */
    public function getIdMembre()
    {
        return $this->idMembre;
    }

    public function getClass()
    {
    	return "Membre";
    }
    
    public function toArray()
    {
    	$pers = $this->idMembre;
    	
    	return array(
    		'nom' => $pers->getNom(),
    		'prenom' => $pers->getPrenom(),
    		'mail' => $pers->getMail(),
    		'tel' => $pers->getTel(),
    		'instrument' => $pers->getInstrumentPratique(),
    		'dateNaissance' => $this->dateNaissance);
    }
}
