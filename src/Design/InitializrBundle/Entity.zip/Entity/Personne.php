<?php

namespace Design\InitializrBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Personne
 *
 * @ORM\Table(name="personne")
 * @ORM\Entity
 */
class Personne
{
	/**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=25, nullable=false)
     * 
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="prenom", type="string", length=25, nullable=false)
     */
    private $prenom;

    /**
     * @var string
     *
     * @ORM\Column(name="mail", type="string", length=50, nullable=false)
     * 
     * @Assert\Email(
     *     message = "Adresse email non valide.",
     *     checkMX = true
     *     )
     */
    private $mail;

    /**
     * @var string
     *
     * @ORM\Column(name="tel", type="string", length=10, nullable=true)
     * 
     * @Assert\Regex(
     *     pattern="/^0[0-9]{9}$/",
     *     match=true,
     *     message="Numero de téléphone invalide"
     * 	   )
     */
    private $tel;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_personne", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idPersonne;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Design\InitializrBundle\Entity\Instrument", inversedBy="personnePratique")
     * @ORM\JoinTable(name="pratique",
     *   joinColumns={
     *     @ORM\JoinColumn(name="personne_pratique", referencedColumnName="id_personne")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="instrument_pratique", referencedColumnName="id_instrument")
     *   }
     * )
     */
    private $instrumentPratique;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Design\InitializrBundle\Entity\Stage", inversedBy="personneParticipe")
     * @ORM\JoinTable(name="participe",
     *   joinColumns={
     *     @ORM\JoinColumn(name="personne_participe", referencedColumnName="id_personne")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="stage_participe", referencedColumnName="id_stage")
     *   }
     * )
     */
    private $stageParticipe;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Design\InitializrBundle\Entity\Stage", mappedBy="personneEstinscrit")
     */
    private $stageEstinscrit;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->instrumentPratique = new \Doctrine\Common\Collections\ArrayCollection();
        $this->stageParticipe = new \Doctrine\Common\Collections\ArrayCollection();
        $this->stageEstinscrit = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Surcharge du constructeur
     * (utilisee dans inscriptionAction() )
     */
    public function persInit($nom, $prenom, $mail, $tel=NULL)
    {
    	$this->nom = $nom;
    	$this->prenom = $prenom;
    	$this->mail = $mail;
    	$this->tel = $tel;
    }


    /**
     * Set nom
     *
     * @param string $nom
     * @return Personne
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set prenom
     *
     * @param string $prenom
     * @return Personne
     */
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * Get prenom
     *
     * @return string 
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Set mail
     *
     * @param string $mail
     * @return Personne
     */
    public function setMail($mail)
    {
        $this->mail = $mail;

        return $this;
    }

    /**
     * Get mail
     *
     * @return string 
     */
    public function getMail()
    {
        return $this->mail;
    }

    /**
     * Set tel
     *
     * @param string $tel
     * @return Personne
     */
    public function setTel($tel)
    {
        $this->tel = $tel;

        return $this;
    }

    /**
     * Get tel
     *
     * @return string 
     */
    public function getTel()
    {
        return $this->tel;
    }

    /**
     * Get idPersonne
     *
     * @return integer 
     */
    public function getIdPersonne()
    {
        return $this->idPersonne;
    }

    /**
     * Add instrumentPratique
     *
     * @param \Design\InitializrBundle\Entity\Instrument $instrumentPratique
     * @return Personne
     */
    public function addInstrumentPratique(\Design\InitializrBundle\Entity\Instrument $instrumentPratique)
    {
        $this->instrumentPratique[] = $instrumentPratique;

        return $this;
    }

    /**
     * Remove instrumentPratique
     *
     * @param \Design\InitializrBundle\Entity\Instrument $instrumentPratique
     */
    public function removeInstrumentPratique(\Design\InitializrBundle\Entity\Instrument $instrumentPratique)
    {
        $this->instrumentPratique->removeElement($instrumentPratique);
    }

    /**
     * Get instrumentPratique
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getInstrumentPratique()
    {
        return $this->instrumentPratique;
    }

    /**
     * Add stageParticipe
     *
     * @param \Design\InitializrBundle\Entity\Stage $stageParticipe
     * @return Personne
     */
    public function addStageParticipe(\Design\InitializrBundle\Entity\Stage $stageParticipe)
    {
        $this->stageParticipe[] = $stageParticipe;

        return $this;
    }

    /**
     * Remove stageParticipe
     *
     * @param \Design\InitializrBundle\Entity\Stage $stageParticipe
     */
    public function removeStageParticipe(\Design\InitializrBundle\Entity\Stage $stageParticipe)
    {
        $this->stageParticipe->removeElement($stageParticipe);
    }

    /**
     * Get stageParticipe
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getStageParticipe()
    {
        return $this->stageParticipe;
    }

    /**
     * Add stageEstinscrit
     *
     * @param \Design\InitializrBundle\Entity\Stage $stageEstinscrit
     * @return Personne
     */
    public function addStageEstinscrit(\Design\InitializrBundle\Entity\Stage $stageEstinscrit)
    {
        $this->stageEstinscrit[] = $stageEstinscrit;

        return $this;
    }

    /**
     * Remove stageEstinscrit
     *
     * @param \Design\InitializrBundle\Entity\Stage $stageEstinscrit
     */
    public function removeStageEstinscrit(\Design\InitializrBundle\Entity\Stage $stageEstinscrit)
    {
        $this->stageEstinscrit->removeElement($stageEstinscrit);
    }

    /**
     * Get stageEstinscrit
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getStageEstinscrit()
    {
        return $this->stageEstinscrit;
    }
    
    public function getClass()
    {
    	return "Personne";
    }
}
