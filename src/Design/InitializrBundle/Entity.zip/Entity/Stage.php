<?php

namespace Design\InitializrBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Stage
 *
 * @ORM\Table(name="stage")
 * @ORM\Entity
 */
class Stage
{
    /**
     * @var string
     *
     * @ORM\Column(name="nom_stage", type="string", length=25, nullable=true)
     */
    private $nomStage;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_debut", type="date", nullable=false)
     */
    private $dateDebut;

    /**
     * @var integer
     *
     * @ORM\Column(name="duree", type="integer", nullable=false)
     */
    private $duree;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=false)
     */
    private $description;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_stage", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idStage;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Design\InitializrBundle\Entity\Instrument", inversedBy="stagePortesur")
     * @ORM\JoinTable(name="portesur",
     *   joinColumns={
     *     @ORM\JoinColumn(name="stage_porteSur", referencedColumnName="id_stage")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="instrument_porteSur", referencedColumnName="id_instrument")
     *   }
     * )
     */
    private $instrumentPortesur;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Design\InitializrBundle\Entity\Personne", mappedBy="stageParticipe")
     */
    private $personneParticipe;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Design\InitializrBundle\Entity\Personne", mappedBy="stageEstinscrit")
     */
    private $personneEstinscrit;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->instrumentPortesur = new \Doctrine\Common\Collections\ArrayCollection();
        $this->personneParticipe = new \Doctrine\Common\Collections\ArrayCollection();
        $this->personneEstinscrit = new \Doctrine\Common\Collections\ArrayCollection();
    }


    /**
     * Set nomStage
     *
     * @param string $nomStage
     * @return Stage
     */
    public function setNomStage($nomStage)
    {
        $this->nomStage = $nomStage;

        return $this;
    }

    /**
     * Get nomStage
     *
     * @return string 
     */
    public function getNomStage()
    {
        return $this->nomStage;
    }

    /**
     * Set dateDebut
     *
     * @param \DateTime $dateDebut
     * @return Stage
     */
    public function setDateDebut($dateDebut)
    {
        $this->dateDebut = $dateDebut;

        return $this;
    }

    /**
     * Get dateDebut
     *
     * @return \DateTime 
     */
    public function getDateDebut()
    {
        return $this->dateDebut;
    }

    /**
     * Set duree
     *
     * @param integer $duree
     * @return Stage
     */
    public function setDuree($duree)
    {
        $this->duree = $duree;

        return $this;
    }

    /**
     * Get duree
     *
     * @return integer 
     */
    public function getDuree()
    {
        return $this->duree;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Stage
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Get idStage
     *
     * @return integer 
     */
    public function getIdStage()
    {
        return $this->idStage;
    }

    /**
     * Add instrumentPortesur
     *
     * @param \Design\InitializrBundle\Entity\Instrument $instrumentPortesur
     * @return Stage
     */
    public function addInstrumentPortesur(\Design\InitializrBundle\Entity\Instrument $instrumentPortesur)
    {
        $this->instrumentPortesur[] = $instrumentPortesur;

        return $this;
    }

    /**
     * Remove instrumentPortesur
     *
     * @param \Design\InitializrBundle\Entity\Instrument $instrumentPortesur
     */
    public function removeInstrumentPortesur(\Design\InitializrBundle\Entity\Instrument $instrumentPortesur)
    {
        $this->instrumentPortesur->removeElement($instrumentPortesur);
    }

    /**
     * Get instrumentPortesur
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getInstrumentPortesur()
    {
        return $this->instrumentPortesur;
    }

    /**
     * Add personneParticipe
     *
     * @param \Design\InitializrBundle\Entity\Personne $personneParticipe
     * @return Stage
     */
    public function addPersonneParticipe(\Design\InitializrBundle\Entity\Personne $personneParticipe)
    {
        $this->personneParticipe[] = $personneParticipe;

        return $this;
    }

    /**
     * Remove personneParticipe
     *
     * @param \Design\InitializrBundle\Entity\Personne $personneParticipe
     */
    public function removePersonneParticipe(\Design\InitializrBundle\Entity\Personne $personneParticipe)
    {
        $this->personneParticipe->removeElement($personneParticipe);
    }

    /**
     * Get personneParticipe
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPersonneParticipe()
    {
        return $this->personneParticipe;
    }

    /**
     * Add personneEstinscrit
     *
     * @param \Design\InitializrBundle\Entity\Personne $personneEstinscrit
     * @return Stage
     */
    public function addPersonneEstinscrit(\Design\InitializrBundle\Entity\Personne $personneEstinscrit)
    {
        $this->personneEstinscrit[] = $personneEstinscrit;

        return $this;
    }

    /**
     * Remove personneEstinscrit
     *
     * @param \Design\InitializrBundle\Entity\Personne $personneEstinscrit
     */
    public function removePersonneEstinscrit(\Design\InitializrBundle\Entity\Personne $personneEstinscrit)
    {
        $this->personneEstinscrit->removeElement($personneEstinscrit);
    }

    /**
     * Get personneEstinscrit
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPersonneEstinscrit()
    {
        return $this->personneEstinscrit;
    }
}
